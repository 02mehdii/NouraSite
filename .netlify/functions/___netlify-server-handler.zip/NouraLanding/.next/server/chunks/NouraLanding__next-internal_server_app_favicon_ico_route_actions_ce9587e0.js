module.exports=[20666,(e,o,d)=>{}];

//# sourceMappingURL=NouraLanding__next-internal_server_app_favicon_ico_route_actions_ce9587e0.js.map