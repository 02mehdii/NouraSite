module.exports=[39196,(a,b,c)=>{}];

//# sourceMappingURL=NouraLanding__next-internal_server_app_privacy_page_actions_a5e8eee4.js.map