module.exports=[95409,(a,b,c)=>{}];

//# sourceMappingURL=NouraLanding__next-internal_server_app__global-error_page_actions_c4ff1a54.js.map