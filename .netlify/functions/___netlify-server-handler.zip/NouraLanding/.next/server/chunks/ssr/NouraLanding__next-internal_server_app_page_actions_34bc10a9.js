module.exports=[52153,(a,b,c)=>{}];

//# sourceMappingURL=NouraLanding__next-internal_server_app_page_actions_34bc10a9.js.map