module.exports=[98213,a=>{a.v("/_next/static/media/favicon.0b3bf435.ico")},98337,a=>{"use strict";let b={src:a.i(98213).default,width:256,height:256};a.s(["default",0,b])}];

//# sourceMappingURL=NouraLanding_src_app_7e14f85b._.js.map